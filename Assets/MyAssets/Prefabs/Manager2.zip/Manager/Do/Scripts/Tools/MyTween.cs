﻿using System;


using DG.Tweening;
using UnityEngine;

namespace Do
{
    public class MyTween : MonoBehaviour
    {
        public static MyTween instance;
        private void Awake()
        {
            if (instance == null)
            {
                instance = this;
            }
        }

        private float _tweenFloat;

        
        public DG.Tweening.Tween DoTween_Float(float Duration, float Delay = 0, Action Complete = null)
        {
            _tweenFloat = 0;
            var tween = DOTween.To(() => _tweenFloat, x => _tweenFloat = x, 1, Duration).SetDelay(Delay).OnComplete(delegate
            {
                Complete?.Invoke();
            });
            return tween;
        }


     
    }
}
