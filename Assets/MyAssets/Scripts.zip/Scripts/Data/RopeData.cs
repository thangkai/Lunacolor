
using System.Collections.Generic;


[System.Serializable]
public class RopeData
{
    public List<int> datas = new List<int>();
}

[System.Serializable]
public class NutData
{
    public NutType nutType;
    public ColorType color;
    public int bombCount;
    public bool isIce;
    public bool isHidden;
}
[System.Serializable]
public class ScrewData
{
    public List<string> nutDatas = new List<string>();
    public int size;
    public int towelColor;
}
[System.Serializable]
public class LevelData
{
    public List<ScrewData> screwList = new List<ScrewData>();
    public List<int> targetColorList = new List<int>();
    public int goalNum;
    public List<RopeData> ropeMap = new List<RopeData>();
    public List<GlassData> glassMap = new List<GlassData>();
}
[System.Serializable]
public class GlassData
{
    public List<int> datas = new List<int>();

}
