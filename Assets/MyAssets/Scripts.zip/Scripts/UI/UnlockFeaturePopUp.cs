using DG.Tweening;
using Do;
using System.Collections.Generic;
using UnityEngine;


public class UnlockFeaturePopUp : PopUpBase
{
    [SerializeField] List<GameObject> iconObjs = new List<GameObject>();
    GameObject currentFeature;
    public override void Open()
    {
        if (currentFeature != null) 
            currentFeature.SetActive(false);
        currentFeature = iconObjs[0];
        currentFeature.SetActive(true);
        base.Open();
        //DOVirtual.DelayedCall(0.7f, () =>
        //{
            AudioManager.Instance.Play(SoundType.Feature_Anounce);
        //});
    }

    public override void Close()
    {
        base.Close();
        DOVirtual.DelayedCall(0.4f, () => 
        {
          //  TutorialController.Instance.OpenTutorial(); 
        });
    }
}
